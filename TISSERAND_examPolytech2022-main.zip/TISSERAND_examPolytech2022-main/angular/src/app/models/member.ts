export interface Member {
    name: string;
    uri: string;
  }
